package fi.leevisavikko.gameendactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class GameEndActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String difficulty = "Easy";
        int CorrectAnswers = 5;
        TextView tv = findViewById(R.id.textView);
        //ImageView iv = findViewById(R.id.imageView);
        if (CorrectAnswers == 5){
            tv.setText("Well played, you got gold");
            if (difficulty.equals("Easy")){
                //EasyG.addcounter();
            }
            else if (difficulty.equals("Medium")){
                //MediumG.addcounter();
            }
            else {
                //HardG.addcounter();
            }
        }
        else if (CorrectAnswers == 4){
            tv.setText("Well played you got silver");
            if (difficulty.equals("Easy")){
                //EasyS.addcounter();
            }
            else if (difficulty.equals("Medium")){
                //MediumS.addcounter();
            }
            else {
                //HardS.addcounter();
            }
        }
        else if (CorrectAnswers == 3){
            tv.setText("Well played, you got bronze");
            if (difficulty.equals("Easy")){
                //EasyB.addcounter();
            }
            else if (difficulty.equals("Medium")){
                //MediumB.addcounter();
            }
            else {
                //HardB.addcounter();
            }
        }
        else {
            tv.setText("Better luck next time");
        }
    }

    public void returnButton(View view){
        //Intent m = new Intent(this, MainActivity.class);
        //startActivity(m);
    }
}